//import express, express router as shown in lecture code
import { Router } from "express";
const router = Router();
import {register, login} from "../data/users.js";
import * as helpers from "../helpers.js";
import {users} from "../config/mongoCollections.js";

export const nameRegex = /^[a-zA-Z]{2,20}$/;
export const idRegex = /^[a-zA-Z0-9]{5,10}$/;
export const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/;
export const hexRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;

router.route('/').get(async (req, res) => {
  //code here for GET
  try {
    return res.render('home', {user: req.session.user, currentTime: new Date().toLocaleTimeString(), currentDate: new Date().toLocaleDateString()});
  }
  catch (e){
    return res.status(500).render('error', {errors: e.message, title: 'Error'});
  }
});

router
  .route('/register')
  .get(async (req, res) => {
    //code here for GET
    try {
      if (req.session.user){
        return res.redirect('/');
      }
      return res.render('register');
    }
    catch (e){
      return res.status(500).render('error', {errors: e.message, title: 'Error'});
    }
  })
  .post(async (req, res) => {
    //code here for POST
    let regData = req.body;
    
      try {
        //input validation
        let firstName = regData.firstName.trim();
        let lastName = regData.lastName.trim();
        let userId = regData.userId.trim();
        let password = regData.password.trim();
        let confirmPassword = regData.confirmPassword.trim();
        let role = regData.role.trim();
        let missingFields = [];
        if (!firstName) missingFields.push('First Name');
        if (!lastName) missingFields.push('Last Name');
        if (!userId) missingFields.push('User ID');
        if (!password) missingFields.push('Password');
        if (!confirmPassword) missingFields.push('Confirmed Password');
        if (!role) missingFields.push('role');

        if (missingFields.length>0){
            return res.status(400).render('register', {errors: true, errorMessage: `${missingFields.toString()} must be filled`});
        }
        if (!nameRegex.test(firstName.trim()) || !nameRegex.test(lastName.trim())){
            return res.status(400).render('register', {errors: true, errorMessage: 'First/Last name must be between 2 and 20 letters, and cannot have spaces'});
        }

        if (!idRegex.test(userId.trim())){
            return res.status(400).render('register', {errors: true, errorMessage: 'User ID must be between 5 and 10 characters, and cannot have spaces'});
        }

        if (!passwordRegex.test(password.trim())){
            return res.status(400).render('register', {errors: true, errorMessage: 'Password must be at least 8 characters, and contain an uppercase letter, a lowercase letter, a number, and a special character'});
        }
    
        if (password !== confirmPassword) {
            return res.status(400).render('register', {errors: true, errorMessage: 'Passwords do not match'});
        }
    
        //register user
        const result = await register(
          firstName.trim(),
          lastName.trim(),
          userId.trim().toLowerCase(),
          password,
          role.toLowerCase()
        );
    
        if (!result.registrationCompleted) {
          throw { code: 500, error: "Registration failed - please try again" };
        }
    
        return res.redirect('/login');
      } catch (e) {
        return res.status(400).render('register', {
          errors: true,
          errorMessage: e
        });
    }
  });

router
  .route('/login')
  .get(async (req, res) => {
    //code here for GET
    return res.render('login');
  })
  .post(async (req, res) => {
    //code here for POST
    const { userId, password } = req.body;
    
    try {
        //validate inputs
        if (!userId || !password) {
            return res.status(400).render('login', {errors: true, errorMessage: 'Please enter User ID and Password'});
        }

        if (typeof userId !== 'string' || userId.trim().length === 0) {
            return res.status(400).render('login', {errors: true, errorMessage: "User ID must be a valid string"});
        }

        if (userId.length < 5 || userId.length > 10) {
            return res.status(400).render('login',{ errors: true, errorMessage: "userId must be between 5 and 10 characters" });
        }

        if (!/^[a-zA-Z0-9]+$/.test(userId)) {
            return res.status(400).render('login',{ errors: true, errorMessage: "userId can only contain letters and numbers" });
        }

        if (typeof password !== 'string' || password.trim().length === 0) {
            return res.status(400).render('login',{ errors: true, errorMessage: "Password must be a valid string" });
        }

        if (password.length < 8) {
            return res.status(400).render('login',{ errors: true, errorMessage: "Password must be at least 8 characters" });
        }

        if (!/(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])/.test(password)) {
            return res.status(400).render('login',{ errors: true, errorMessage: "password must contain at least one uppercase letter, one number, and one special character" });
        }

        //login user
        const user = await login(userId.toLowerCase(), password); 

        //store in session
        req.session.user = {
            firstName: user.firstName,
            lastName: user.lastName,
            userId: user.userId,
            role: user.role,
            signupDate: user.signupDate,
            lastLogin: user.lastLogin
        };
        res.cookie("AuthenticationState", 'Authenticated');

        //redirect according to role
        if (user.role === 'administrator') {
            return res.redirect('/superuser');
        } else {
            return res.redirect('/user');
        }
    } catch (e) {
        if (e.code) {
            return res.status(400).render('login', { 
                errors: true, 
                errorMessage:"Either the userId or password is invalid"
            });
        }
        return res.status(400).render('login', {
            errors: true,
            errorMessage: "Either the userId or password is invalid",
            userId: req.body.userId // Preserve userId in form
        });
    }
  });

router.route('/user').get(async (req, res) => {
  //code here for GET
  let currUser = req.session.user;
  let t = new Date().toLocaleTimeString();
  let d = new Date().toLocaleDateString();
  let suCheck = req.session.user && req.session.user.role==='administrator';
  return res.render('user', {users: true, firstName: currUser.firstName, lastName: currUser.lastName, currentTime: t, currentDate: d,
    role: currUser.role, signupDate: currUser.signupDate, lastLogin: currUser.lastLogin, user: currUser
  })
});

router.route('/superuser').get(async (req, res) => {
  //code here for GET
  let currUser = req.session.user;
  let t = new Date().toLocaleTimeString();
  let d = new Date().toLocaleDateString();
  return res.render('superuser', {users: true, firstName: currUser.firstName, lastName: currUser.lastName, currentTime: t, currentDate: d,
    signupDate: currUser.signupDate, lastLogin: currUser.lastLogin, user: currUser
  });
});

router.route('/signout').get(async (req, res) => {
  res.clearCookie('AuthenticationState', '', {expires: new Date()});
  req.session.destroy();
  return res.render('signout');
});

export default router;