//import mongo collections, bcrypt and implement the following data functions
import { users } from "../config/mongoCollections.js";
import * as helpers from "../helpers.js";
import bcrypt from "bcrypt";
const saltRounds = 16;

export const register = async (
  firstName,
  lastName,
  userId,
  password,
  role
) => {
  if (!firstName || !lastName || !userId || !password || !role){
    throw "Error: All fields must be supplied";
  }

  firstName = helpers.validateName(firstName, 'First name');
  lastName = helpers.validateName(lastName, 'Last name');
  userId = helpers.validateUserId(userId);
  password = helpers.validatePassword(password);
  role = helpers.validateRole(role);

  const userCollection = await users();
  let exists = await userCollection.findOne({userId: userId});
  if (exists){
    throw "Error: There is already a user with this User ID";
  }

  const hashedPass = await bcrypt.hash(password, saltRounds);
  const td = new Date();
  const signupDate = `${(td.getMonth() + 1).toString().padStart(2, '0')}/${td.getDate().toString().padStart(2, '0')}/${td.getFullYear()}`;

  const newUser = {
    firstName: firstName,
    lastName: lastName,
    userId: userId,
    password: hashedPass,
    role: role,
    signupDate: signupDate,
    lastLogin: ""
  };

  const inserted = await userCollection.insertOne(newUser);
  if (!inserted){
    throw "Error: Coult not register user";
  }
  return {registrationCompleted: true};
};

export const login = async (userId, password) => {
  if (!userId || !password){
    throw "Error: userId and password must be provided";
  }
  userId = helpers.validateUserId(userId);
  password = helpers.validatePassword(password);
  

  const userCollection = await users();
  const user = await userCollection.findOne({userId: userId});
  if (!user){
    throw "Either the userId or password is invalid";
  }

  const matched = await bcrypt.compare(password, user.password);
  if (!matched){
    throw "Either the userId or password is invalid";
  }
  const td = new Date();
  const hours = td.getHours();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const twelveHour = hours % 12 || 12; // Convert to 12-hour format
  const lastLogin = `${(td.getMonth() + 1).toString().padStart(2, '0')}/` +
                   `${td.getDate().toString().padStart(2, '0')}/` +
                   `${td.getFullYear()} ` +
                   `${twelveHour.toString().padStart(2, '0')}:` +
                   `${td.getMinutes().toString().padStart(2, '0')}${ampm}`;
  await userCollection.updateOne(
    {_id: user._id},
    {$set: {lastLogin: lastLogin}}
  );
  const retUser = {
    firstName: user.firstName,
    lastName: user.lastName,
    userId: user.userId,
    role: user.role,
    signupDate: user.signupDate,
    lastLogin: lastLogin
  };
  return retUser;
};
